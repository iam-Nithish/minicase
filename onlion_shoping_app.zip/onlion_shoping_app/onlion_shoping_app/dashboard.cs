﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace onlion_shoping_app
{
    public partial class dashboard : Form
    {
        public dashboard()
        {
            InitializeComponent();
        }
        
        private void search_TextChanged(object sender, EventArgs e)
        {
            if (search.Text == "search for products.....")
            {

                search.Text = "";

                search.ForeColor = Color.Black;

            }

        }
        private void InitializeMyScrollBar()
        {
            // Create and initialize a VScrollBar.
            VScrollBar vScrollBar1 = new VScrollBar();

            // Dock the scroll bar to the right side of the form.
            vScrollBar1.Dock = DockStyle.Right;

            // Add the scroll bar to the form.
            Controls.Add(vScrollBar1);
        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
           
        }

        private void dashboard_Load(object sender, EventArgs e)
        {
           
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            panel1.Location = new Point(this.ClientSize.Width / 2 - panel1.Size.Width / 2,
            this.ClientSize.Height / 2 - panel1.Size.Height / 2);
            panel1.Anchor = AnchorStyles.None;

            panel1.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel1.Width, panel1.Height, 30, 30));

        }

        private IntPtr CreateRoundRectRgn(int v1, int v2, int width, int height, int v3, int v4)
        {
            throw new NotImplementedException();
        }

        private void search_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}
