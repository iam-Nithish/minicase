﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace onlion_shoping_app
{
    public partial class loginform : Form
    {
        public loginform()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {


        }
          [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]


            private static extern IntPtr CreateRoundRectRgn

            (
              int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse
             );

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Location = new Point(this.ClientSize.Width / 2 - panel1.Size.Width / 2,
            this.ClientSize.Height / 2 - panel1.Size.Height / 2);
            panel1.Anchor = AnchorStyles.None;

            panel1.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel1.Width, panel1.Height, 30, 30));

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                string username = textBox1.Text.Trim();
                string password = textBox2.Text.Trim();
                string role = comboBox1.SelectedItem?.ToString(); // Make sure a role is selected

                if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(role))
                {
                    MessageBox.Show("Please fill in all fields.");
                    return;
                }
                using (var context = new onlineshopingEntities())
                {
                    var user = context.users.FirstOrDefault(u => u.Username == username && u.password == password && u.Role == role);

                    if (user != null)
                    {
                        MessageBox.Show("Login successful!");

                        if (role == "User")
                        {
                            dashboard customerDashboard = new dashboard();
                            customerDashboard.Show();
                        }
                        else if (role == "Admin")
                        {
                            admindashboard adminDashboard = new admindashboard();
                            adminDashboard.Show();
                        }

                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Invalid username, password, or role. Please try again.");
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void label4_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Hide();

            signupform signup = new signupform();

            signup.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
