﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace onlion_shoping_app
{
    public partial class signupform : Form
    {
        public signupform()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.Hide();

            signupform login = new signupform();

            login.Show();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
            private static extern IntPtr CreateRoundRectRgn

            (
              int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse
             );

        private void Form2_Load(object sender, EventArgs e)
        {
            panel1.Location = new Point(this.ClientSize.Width / 2 - panel1.Size.Width / 2,
           this.ClientSize.Height / 2 - panel1.Size.Height / 2);
            panel1.Anchor = AnchorStyles.None;

            panel1.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel1.Width, panel1.Height, 30, 30));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();

            loginform login = new loginform();

            login.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String fullname = textBox5.Text;
            String USERNAME = textBox4.Text;
            String PASSWORD = textBox3.Text;
            String confirmpassword = textBox2.Text;
            String role = comboBox1.Text.ToString();

            if (string.IsNullOrEmpty(fullname) || string.IsNullOrEmpty(USERNAME) ||
    string.IsNullOrEmpty(PASSWORD) || string.IsNullOrEmpty(confirmpassword))
            {
                MessageBox.Show("All fields are required. Please fill in all fields.");
                return;
            }

            // Check if password and confirm password match
            if (PASSWORD != confirmpassword)
            {
                MessageBox.Show("Password and Confirm Password do not match.");
                textBox3.Clear();
                textBox4.Clear();
                return;
            }

            //Connect to the database and check if the username already exists
            using (var context = new onlineshopingEntities())  // Replace with your actual DbContext name
            {
                // Check if the username already exists
                var existingUser = context.users.FirstOrDefault(u => u.Username == USERNAME);
                if (existingUser != null)
                {
                    MessageBox.Show("Username already exists. Please choose a different username.");
                    textBox2.Clear();
                    return;
                }

                // Create a new user with the role of 'User'
                var newUser = new user
                {
                    Fullname = fullname,
                    Username = USERNAME,
                    password = PASSWORD,  // Consider hashing the password for security in a real application
                    Role = role  // This will always be "User"
                };
                //Add the new user to the database
                context.users.Add(newUser);
                context.SaveChanges();

                MessageBox.Show("Signup successful! You can now log in with your credentials.");
                this.Close();
            }






            this.Hide();

            loginform login1 = new loginform();

            login1.Show();
        }
    }
}
