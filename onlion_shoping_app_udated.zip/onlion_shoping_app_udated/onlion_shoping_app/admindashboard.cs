﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace onlion_shoping_app
{
    public partial class admindashboard : Form
    {
        public admindashboard()
        {
            InitializeComponent();
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripTextBox2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        //private void button1_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        //int productid = textBox1.Text.Trim();
        //        string productname = textBox2.Text.Trim();

        //        decimal Pricee;



        //        string category = comboBox1.SelectedItem?.ToString();
        //        string description = textBox5.Text.Trim();
        //        string imageurl = textBox6.ToString();



        //        //Validate inputs
        //        if (string.IsNullOrWhiteSpace(productname) || string.IsNullOrWhiteSpace(description) ||
        //            !decimal.TryParse(textBox3.Text, out Pricee))
        //        {
        //            MessageBox.Show("Please fill out all required fields correctly.");
        //            return;
        //        }

        //        //Using Entity Framework context to interact with the database
        //        using (var context = new onlineshopingEntities()) // Replace YourDbContext with your actual DbContext class name
        //        {
        //            try
        //            {
        //                Product products = new Product();
        //                {
        //                    Name = productname;
        //                     Price = Pricee;
        //                     Description = description;
        //                     Category = category;
        //                     ImageUrl = imageurl;
        //                };


        //                context.Products.Add(products);

        //                // Save the changes to the database
        //                context.SaveChanges();

        //                // Confirm the insertion
        //                MessageBox.Show("Product added successfully!");
        //            }
        //            catch (Exception ex)
        //            {
        //                MessageBox.Show(ex.Message);
        //            }


        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Collect inputs
                string productname = textBox2.Text.Trim();
                string category = comboBox1.SelectedItem?.ToString();
                string description = textBox5.Text.Trim();
                string imageurl = textBox6.Text.Trim();
                decimal Pricee;

                // Validate inputs
                if (string.IsNullOrWhiteSpace(productname) || string.IsNullOrWhiteSpace(description) ||
                    !decimal.TryParse(textBox3.Text, out Pricee))
                {
                    MessageBox.Show("Please fill out all required fields correctly.");
                    return;
                }

                // Using Entity Framework context to interact with the database
                using (var context = new onlineshopingEntities()) // Replace onlineshopingEntities with your actual DbContext class name
                {
                    try
                    {
                        // Create a new Product object and set its properties
                        Product product = new Product
                        {
                            Name = productname,
                            Price = Pricee,
                            Description = description,
                            Category = category,
                            ImageUrl = imageurl
                        };

                        // Add the product to the context
                        context.Products.Add(product);

                        // Save the changes to the database
                        context.SaveChanges();

                        // Confirm the insertion
                        MessageBox.Show("Product added successfully!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                // Collect inputs
                int ProductId;
                if (!int.TryParse(textBox9.Text.Trim(), out ProductId))
                {
                    MessageBox.Show("Please enter a valid Product ID.");
                    return;
                }

                string productname = textBox8.Text.Trim();
                string category = comboBox2.SelectedItem?.ToString();
                string description = textBox4.Text.Trim();
                string imageurl = textBox1.Text.Trim();
                decimal pricee;

                // Validate inputs
                if (string.IsNullOrWhiteSpace(productname) || string.IsNullOrWhiteSpace(description) ||
                    !decimal.TryParse(textBox7.Text, out pricee))
                {
                    MessageBox.Show("Please fill out all required fields correctly.");
                    return;
                }

                // Using Entity Framework context to interact with the database
                using (var context = new onlineshopingEntities()) // Replace onlineshopingEntities with your actual DbContext class name
                {
                    try
                    {
                        // Find the product by ID
                        var product = context.Products.SingleOrDefault(p => p.ProductId == ProductId); // Replace ProductId with your actual primary key property

                        if (product == null)
                        {
                            MessageBox.Show("Product not found.");
                            return;
                        }

                        // Update the product's properties
                        product.Name = productname;
                        product.Price = pricee;
                        product.Description = description;
                        product.Category = category;
                        product.ImageUrl = imageurl;

                        // Save the changes to the database
                        context.SaveChanges();

                        // Confirm the update
                        MessageBox.Show("Product updated successfully!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            try
            {
                // Retrieve the ProductID from the input
                int productId;
                if (!int.TryParse(textBox10.Text.Trim(), out productId))
                {
                    MessageBox.Show("Please enter a valid Product ID.");
                    return;
                }

                // Using Entity Framework context to interact with the database
                using (var context = new onlineshopingEntities()) // Replace onlineshopingEntities with your actual DbContext class name
                {
                    try
                    {
                        // Find the product by ProductID
                        var product = context.Products.SingleOrDefault(p => p.ProductId == productId);

                        if (product == null)
                        {
                            MessageBox.Show("Product not found.");
                            return;
                        }

                        // Remove the product from the context
                        context.Products.Remove(product);

                        // Save the changes to the database
                        context.SaveChanges();

                        // Confirm the deletion
                        MessageBox.Show("Product deleted successfully!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            using (var context = new onlineshopingEntities()) // Replace with your actual DbContext class
            {
                try
                {
                    // Fetch all mobile records from the database
                    var medicine = context.Products.ToList();

                    // Bind the list of mobiles to the DataGridView
                    dataGridView1.DataSource = medicine;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
    }
}
    



       