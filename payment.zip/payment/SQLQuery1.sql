use nithish


create table cards
(
 cardid int primary key identity,
 cardholdername varchar(50),
 cardnumber varchar(50),
 expmonth int,
 expyear int,
 cvv int
 )

 create table upipayment
 (
 upiid int primary key identity,
 upinumber varchar(50)
 )

 create table otp
 (

 otpid int primary key identity,
 otpnumber varchar(50)
 )