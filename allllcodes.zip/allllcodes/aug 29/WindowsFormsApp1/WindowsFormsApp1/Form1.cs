﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //linq to objects
            string[] namesvalue = { "nithish", "kishore", "shashank" };
            //var resulvalue = from s in namesvalue
            //                 where s.Length > 4
            //                 select s.ToUpper();
            var resulvalue = from s in namesvalue
                            where s=="nithish"
                            select s;
            foreach ( var name in resulvalue )
            {
                listBox1.Items.Add( name ); 
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {

                List<string> namesvalue = new List<string>
                {

                     "Here is the query variable which stores"+ "the query expression"+
                 "so, we use where methos to filters the data cource"
                  };

                var restuvalue = namesvalue.Where(b => b.Contains("data"));

                foreach (var name in restuvalue)
                {

                    listBox2.Items.Add(name);
                }
            }

            catch (Exception ex)

            {

                MessageBox.Show(ex.Message);

            }

        }
    }
}
