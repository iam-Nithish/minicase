﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            try
            {
                List<string> list = new List<string>();
                list.Add("cit");
                list.Add("vgse");
                list.Add("svnc");
                list.Add("dfgr");
                //linq to object
                //var samplevalue = list.Select(x => x);
                IEnumerable<string> samplevalue = list.Select(x => x);
                foreach (var item in samplevalue)
                {
                    listBox1.Items.Add(item);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
