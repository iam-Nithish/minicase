﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ado
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

      

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection sqlconnection = new SqlConnection();
                
                sqlconnection.ConnectionString = "Data source=INBLRWHFCHPXJ23;" + "Initial Catalog=nithish;Integrated Security=false;uid=sa;pwd=Nttdata@123";
                sqlconnection.Open();
                SqlCommand cmd = new SqlCommand("insert into incometax(pancardnumber,cardholderman,mobilenumber)" +
                    "values(@pancardnumber,@cardholderman,@mobilenumber)", sqlconnection);
                cmd.Parameters.AddWithValue("@pancardnumber", Convert.ToInt32(textBox1.Text));
                cmd.Parameters.AddWithValue("@cardholderman", (textBox2.Text));
                cmd.Parameters.AddWithValue("@mobilenumber", (textBox3.Text));
                int resultvalue=cmd.ExecuteNonQuery();
                if(resultvalue>0)
                {
                    MessageBox.Show("insertion successful");

                }
                else
                {
                    MessageBox.Show("insertion failed");
                }
               
                
                sqlconnection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
