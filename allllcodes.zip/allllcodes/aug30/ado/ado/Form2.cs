﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ado
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection sqlconnection = new SqlConnection();

                sqlconnection.ConnectionString = "Data source=INBLRWHFCHPXJ23;" + "Initial Catalog=nithish;Integrated Security=false;uid=sa;pwd=Nttdata@123";
                sqlconnection.Open();
                SqlCommand cmd = new SqlCommand("select count(pancardnumber)'total tax' from incometax", sqlconnection);
               
                object resultvalue = cmd.ExecuteScalar();
                textBox1.Text=resultvalue.ToString();


                sqlconnection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
