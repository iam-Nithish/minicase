﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ado
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection sqlconnection = new SqlConnection();

                sqlconnection.ConnectionString = "Data source=INBLRWHFCHPXJ23;" + "Initial Catalog=nithish;Integrated Security=false;uid=sa;pwd=Nttdata@123";





                SqlDataAdapter adapter = new SqlDataAdapter("select * from incometax", sqlconnection);
                DataSet ds = new DataSet();

                adapter.Fill(ds, "incometaxdetails");
                //linq to dataset
                var resultvalue= from d in ds.Tables[0].AsEnumerable() select d;
                dataGridView1.DataSource = resultvalue.AsDataView();


              
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
